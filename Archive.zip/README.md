# COMP 472 Mini Project 

https://github.com/antonio-crispino/COMP472_Mini_Project


##### Antonio Crispino - 40109690 

##### Maira Malhi - 40128269 

##### Nabila Mehreen - 40130897 


## Instructions on how to run your program 

1. Download a ZIP of our project
2. Go Into the Following Paths and open the .py files in your editor of choice

    (For Part 1)  -> COMP 472/Mini Project/Untitled/Mini_Project_1/Part_1 
      
    (For Part 2)  -> COMP 472/Mini Project/Untitled/Mini_Project_1/Part_2 
    
    (For Part 3)  -> COMP 472/Mini Project/Untitled/Mini_Project_1/Part_2 
    
3. Install the following packages:

  - matplotlib
  - sklearn
  
  Makes ure you have the following preinstalled / configrued in your python interpreter 
 - gzip
 - json
 - os
 - numpy 
 - pyplot

4. Run the .py files.
